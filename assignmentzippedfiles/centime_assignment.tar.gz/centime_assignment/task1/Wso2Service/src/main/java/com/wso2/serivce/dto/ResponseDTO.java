package com.wso2.serivce.dto;

import lombok.Data;

@Data
public class ResponseDTO {

	private String fullName;
}
