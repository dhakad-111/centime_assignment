package com.springboot.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootApi1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootApi1Application.class, args);
	}

}
