package com.microservices.dto;

import lombok.Data;

@Data
public class InfoDTO {

	private String name;
	private String color;

}
