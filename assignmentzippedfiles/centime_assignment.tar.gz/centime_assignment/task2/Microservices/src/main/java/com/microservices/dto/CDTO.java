package com.microservices.dto;

import lombok.Data;

@Data
public class CDTO {

	private String name;

}
