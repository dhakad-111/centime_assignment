package com.microservices.dto;

import lombok.Data;

@Data
public class ColorDTO {

	private String name;

}
