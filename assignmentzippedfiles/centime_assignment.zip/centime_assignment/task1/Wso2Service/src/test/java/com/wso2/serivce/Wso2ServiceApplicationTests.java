package com.wso2.serivce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Wso2ServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
