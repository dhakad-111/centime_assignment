package com.wso2.serivce.dto;

import lombok.Data;

@Data
public class MessageDTO {

	private String greeting;
	private String name;
	private String surname;

}
