package com.springboot.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootApi1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
