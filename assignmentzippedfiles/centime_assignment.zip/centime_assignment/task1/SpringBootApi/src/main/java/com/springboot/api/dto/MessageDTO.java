package com.springboot.api.dto;

import lombok.Data;

@Data
public class MessageDTO {

	private String greeting;
}
